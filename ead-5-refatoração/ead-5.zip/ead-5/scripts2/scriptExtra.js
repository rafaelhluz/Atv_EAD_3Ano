// Código duplicado sem necessidade
function exibirUsuarios() {
    for (var i = 0; i < usuariosArray.length; i++) {
        console.log("Usuário: " + usuariosArray[i].nome + " - Email: " + usuariosArray[i].email);
    }
}
