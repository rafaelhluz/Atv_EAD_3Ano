* Toda a documentação do projeto 100%

* 100% esta top de mais!